<?php
/**
 * Plugin Name: WACRM Central
 * Description: Lightweight licensing, entitlement signing, WooCommerce issuance, and update metadata authority for WACRM installations.
 * Version: 0.1.0
 * Author: WACRM
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * Text Domain: wacrm-central
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'WACRM_CENTRAL_VERSION', '0.1.0' );
define( 'WACRM_CENTRAL_FILE', __FILE__ );
define( 'WACRM_CENTRAL_DIR', plugin_dir_path( __FILE__ ) );

require_once WACRM_CENTRAL_DIR . 'includes/class-wacrm-central-db.php';
require_once WACRM_CENTRAL_DIR . 'includes/class-wacrm-central-crypto.php';
require_once WACRM_CENTRAL_DIR . 'includes/class-wacrm-central-license-service.php';
require_once WACRM_CENTRAL_DIR . 'includes/class-wacrm-central-rest.php';
require_once WACRM_CENTRAL_DIR . 'includes/class-wacrm-central-woocommerce.php';
require_once WACRM_CENTRAL_DIR . 'includes/class-wacrm-central-admin.php';

register_activation_hook( __FILE__, array( 'WACRM_Central_DB', 'activate' ) );

function wacrm_central_boot() {
    WACRM_Central_DB::maybe_upgrade();
    WACRM_Central_Crypto::ensure_keypair();

    $service = new WACRM_Central_License_Service();

    ( new WACRM_Central_REST( $service ) )->register();
    ( new WACRM_Central_WooCommerce( $service ) )->register();

    if ( is_admin() ) {
        ( new WACRM_Central_Admin( $service ) )->register();
    }
}
add_action( 'plugins_loaded', 'wacrm_central_boot', 20 );
