<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

// Intentionally preserve licenses, activations, releases, and signing keys.
// Commercial authority data must never be deleted merely by uninstalling the plugin.
