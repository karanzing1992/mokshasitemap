<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WACRM_Central_Crypto {
    const PRIVATE_OPTION = 'wacrm_central_private_key_enc';
    const PUBLIC_OPTION  = 'wacrm_central_public_key';

    public static function ensure_keypair() {
        if ( get_option( self::PRIVATE_OPTION ) && get_option( self::PUBLIC_OPTION ) ) {
            return true;
        }

        if ( ! function_exists( 'openssl_pkey_new' ) ) {
            return false;
        }

        $resource = openssl_pkey_new(
            array(
                'private_key_bits' => 2048,
                'private_key_type' => OPENSSL_KEYTYPE_RSA,
            )
        );

        if ( ! $resource ) {
            return false;
        }

        $private = '';
        if ( ! openssl_pkey_export( $resource, $private ) ) {
            return false;
        }

        $details = openssl_pkey_get_details( $resource );
        if ( empty( $details['key'] ) ) {
            return false;
        }

        update_option( self::PRIVATE_OPTION, self::encrypt_secret( $private ), false );
        update_option( self::PUBLIC_OPTION, $details['key'], false );
        return true;
    }

    public static function get_public_key() {
        return (string) get_option( self::PUBLIC_OPTION, '' );
    }

    public static function get_private_key() {
        $cipher = get_option( self::PRIVATE_OPTION, '' );
        if ( ! $cipher ) {
            return '';
        }
        return self::decrypt_secret( $cipher );
    }

    public static function encrypt_secret( $plaintext ) {
        if ( ! function_exists( 'openssl_encrypt' ) ) {
            return base64_encode( (string) $plaintext ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
        }

        $key = self::storage_key();
        $iv = random_bytes( 12 );
        $tag = '';
        $ciphertext = openssl_encrypt( (string) $plaintext, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag );
        if ( false === $ciphertext ) {
            return '';
        }

        return base64_encode( $iv . $tag . $ciphertext ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
    }

    public static function decrypt_secret( $encoded ) {
        $raw = base64_decode( (string) $encoded, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
        if ( false === $raw ) {
            return '';
        }

        if ( ! function_exists( 'openssl_decrypt' ) ) {
            return $raw;
        }

        if ( strlen( $raw ) < 29 ) {
            return '';
        }

        $iv = substr( $raw, 0, 12 );
        $tag = substr( $raw, 12, 16 );
        $ciphertext = substr( $raw, 28 );
        $plain = openssl_decrypt( $ciphertext, 'aes-256-gcm', self::storage_key(), OPENSSL_RAW_DATA, $iv, $tag );
        return false === $plain ? '' : $plain;
    }

    public static function sign_payload( array $payload ) {
        $private = self::get_private_key();
        if ( ! $private || ! function_exists( 'openssl_sign' ) ) {
            return new WP_Error( 'wacrm_signing_unavailable', 'Entitlement signing is unavailable.' );
        }

        $json = wp_json_encode( $payload, JSON_UNESCAPED_SLASHES );
        $encoded_payload = self::base64url_encode( $json );
        $signature = '';

        if ( ! openssl_sign( $encoded_payload, $signature, $private, OPENSSL_ALGO_SHA256 ) ) {
            return new WP_Error( 'wacrm_signing_failed', 'Could not sign entitlement.' );
        }

        return array(
            'alg'       => 'RS256',
            'payload'   => $encoded_payload,
            'signature' => self::base64url_encode( $signature ),
        );
    }

    public static function random_token( $bytes = 32 ) {
        return self::base64url_encode( random_bytes( absint( $bytes ) ) );
    }

    public static function base64url_encode( $value ) {
        return rtrim( strtr( base64_encode( $value ), '+/', '-_' ), '=' ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
    }

    private static function storage_key() {
        $material = function_exists( 'wp_salt' ) ? wp_salt( 'auth' ) . wp_salt( 'secure_auth' ) : AUTH_KEY . SECURE_AUTH_KEY;
        return hash( 'sha256', $material, true );
    }
}
