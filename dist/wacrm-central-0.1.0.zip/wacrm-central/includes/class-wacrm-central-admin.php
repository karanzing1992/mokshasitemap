<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WACRM_Central_Admin {
    private $service;

    public function __construct( WACRM_Central_License_Service $service ) {
        $this->service = $service;
    }

    public function register() {
        add_action( 'admin_menu', array( $this, 'menu' ) );
        add_action( 'admin_post_wacrm_create_test_license', array( $this, 'create_test_license' ) );
        add_action( 'admin_post_wacrm_create_release', array( $this, 'create_release' ) );
    }

    public function menu() {
        add_menu_page( 'WACRM Central', 'WACRM Central', 'manage_options', 'wacrm-central', array( $this, 'dashboard' ), 'dashicons-admin-network', 56 );
        add_submenu_page( 'wacrm-central', 'Licenses', 'Licenses', 'manage_options', 'wacrm-central-licenses', array( $this, 'licenses' ) );
        add_submenu_page( 'wacrm-central', 'Releases', 'Releases', 'manage_options', 'wacrm-central-releases', array( $this, 'releases' ) );
    }

    public function dashboard() {
        global $wpdb;
        $license_count = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . WACRM_Central_DB::licenses_table() ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        $activation_count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . WACRM_Central_DB::activations_table() . " WHERE status='active'" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        $release_count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . WACRM_Central_DB::releases_table() . " WHERE status='published'" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        $base = rest_url( 'wacrm-central/v1/' );
        ?>
        <div class="wrap">
            <h1>WACRM Central</h1>
            <?php
            $new_key = get_transient( 'wacrm_new_license_' . get_current_user_id() );
            if ( $new_key ) :
                delete_transient( 'wacrm_new_license_' . get_current_user_id() );
                ?>
                <div class="notice notice-success"><p>Test license created: <code><?php echo esc_html( $new_key ); ?></code></p></div>
            <?php endif; ?>
            <p>Low-load licensing and update authority. Customer WhatsApp traffic never passes through this site.</p>
            <table class="widefat striped" style="max-width:800px"><tbody>
                <tr><td><strong>Licenses</strong></td><td><?php echo esc_html( $license_count ); ?></td></tr>
                <tr><td><strong>Active installations</strong></td><td><?php echo esc_html( $activation_count ); ?></td></tr>
                <tr><td><strong>Published releases</strong></td><td><?php echo esc_html( $release_count ); ?></td></tr>
                <tr><td><strong>API base</strong></td><td><code><?php echo esc_html( $base ); ?></code></td></tr>
            </tbody></table>

            <h2>Create test license</h2>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="max-width:800px">
                <?php wp_nonce_field( 'wacrm_create_test_license' ); ?>
                <input type="hidden" name="action" value="wacrm_create_test_license">
                <table class="form-table"><tbody>
                    <tr><th>Plan</th><td><input name="plan_slug" value="pro" class="regular-text"></td></tr>
                    <tr><th>Activations</th><td><input type="number" min="1" name="max_activations" value="1"></td></tr>
                    <tr><th>Days</th><td><input type="number" min="0" name="days" value="30"> <span class="description">0 = no expiry</span></td></tr>
                    <tr><th>Entitlements JSON</th><td><textarea name="entitlements" rows="5" class="large-text code">{"automations":true,"agents":5}</textarea></td></tr>
                </tbody></table>
                <?php submit_button( 'Create license' ); ?>
            </form>

            <h2>Signing public key</h2>
            <p>Embed this public key in the customer plugin build so it can validate entitlements locally.</p>
            <textarea readonly rows="8" class="large-text code"><?php echo esc_textarea( WACRM_Central_Crypto::get_public_key() ); ?></textarea>
        </div>
        <?php
    }

    public function licenses() {
        global $wpdb;
        $rows = $wpdb->get_results( 'SELECT * FROM ' . WACRM_Central_DB::licenses_table() . ' ORDER BY id DESC LIMIT 200', ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        ?>
        <div class="wrap"><h1>WACRM Licenses</h1>
        <table class="widefat striped"><thead><tr><th>ID</th><th>Key</th><th>Plan</th><th>Status</th><th>Sites</th><th>Expires</th><th>Order</th><th>Created</th></tr></thead><tbody>
        <?php foreach ( $rows as $row ) :
            $active = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM " . WACRM_Central_DB::activations_table() . " WHERE license_id=%d AND status='active'", $row['id'] ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
            ?>
            <tr><td><?php echo esc_html( $row['id'] ); ?></td><td><code>…<?php echo esc_html( $row['license_key_hint'] ); ?></code></td><td><?php echo esc_html( $row['plan_slug'] ); ?></td><td><?php echo esc_html( $row['status'] ); ?></td><td><?php echo esc_html( $active . '/' . $row['max_activations'] ); ?></td><td><?php echo esc_html( $row['expires_at'] ?: 'Never' ); ?></td><td><?php echo esc_html( $row['order_id'] ?: '—' ); ?></td><td><?php echo esc_html( $row['created_at'] ); ?></td></tr>
        <?php endforeach; ?>
        </tbody></table></div>
        <?php
    }

    public function releases() {
        global $wpdb;
        $rows = $wpdb->get_results( 'SELECT * FROM ' . WACRM_Central_DB::releases_table() . ' ORDER BY id DESC LIMIT 100', ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        ?>
        <div class="wrap"><h1>WACRM Releases</h1>
            <?php if ( isset( $_GET['wacrm_release_created'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
                <div class="notice notice-success"><p>Release saved.</p></div>
            <?php endif; ?>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="max-width:900px">
                <?php wp_nonce_field( 'wacrm_create_release' ); ?>
                <input type="hidden" name="action" value="wacrm_create_release">
                <table class="form-table"><tbody>
                    <tr><th>Plugin slug</th><td><input name="plugin_slug" value="wacrm" class="regular-text" required></td></tr>
                    <tr><th>Plugin name</th><td><input name="plugin_name" value="WACRM" class="regular-text" required></td></tr>
                    <tr><th>Version</th><td><input name="version" placeholder="0.1.0" required></td></tr>
                    <tr><th>Channel</th><td><select name="channel"><option value="stable">stable</option><option value="beta">beta</option></select></td></tr>
                    <tr><th>Artifact URL</th><td><input type="url" name="artifact_url" class="large-text" placeholder="https://cdn.example.com/wacrm.zip" required></td></tr>
                    <tr><th>Requires WP</th><td><input name="requires_wp" value="6.2"></td></tr>
                    <tr><th>Tested WP</th><td><input name="tested_wp" value=""></td></tr>
                    <tr><th>Requires PHP</th><td><input name="requires_php" value="7.4"></td></tr>
                    <tr><th>SHA-256</th><td><input name="checksum_sha256" class="large-text code"></td></tr>
                    <tr><th>Homepage</th><td><input type="url" name="homepage_url" class="large-text"></td></tr>
                    <tr><th>Changelog</th><td><textarea name="changelog" rows="6" class="large-text"></textarea></td></tr>
                </tbody></table>
                <?php submit_button( 'Publish release metadata' ); ?>
            </form>

            <h2>Recent releases</h2>
            <table class="widefat striped"><thead><tr><th>Plugin</th><th>Version</th><th>Channel</th><th>Artifact</th><th>Published</th></tr></thead><tbody>
            <?php foreach ( $rows as $row ) : ?>
                <tr><td><?php echo esc_html( $row['plugin_slug'] ); ?></td><td><?php echo esc_html( $row['version'] ); ?></td><td><?php echo esc_html( $row['channel'] ); ?></td><td><a href="<?php echo esc_url( $row['artifact_url'] ); ?>" target="_blank" rel="noopener">artifact</a></td><td><?php echo esc_html( $row['published_at'] ); ?></td></tr>
            <?php endforeach; ?>
            </tbody></table>
        </div>
        <?php
    }

    public function create_test_license() {
        if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'wacrm_create_test_license' ) ) {
            wp_die( 'Not allowed.' );
        }

        $entitlements = json_decode( isset( $_POST['entitlements'] ) ? wp_unslash( $_POST['entitlements'] ) : '{}', true ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
        if ( ! is_array( $entitlements ) ) {
            $entitlements = array();
        }
        $days = isset( $_POST['days'] ) ? absint( $_POST['days'] ) : 30;
        $result = $this->service->create_license( array(
            'plan_slug' => isset( $_POST['plan_slug'] ) ? sanitize_key( wp_unslash( $_POST['plan_slug'] ) ) : 'pro',
            'max_activations' => isset( $_POST['max_activations'] ) ? max( 1, absint( $_POST['max_activations'] ) ) : 1,
            'expires_at' => $days ? gmdate( 'Y-m-d H:i:s', time() + DAY_IN_SECONDS * $days ) : null,
            'entitlements' => $entitlements,
        ) );

        if ( is_wp_error( $result ) ) {
            wp_die( esc_html( $result->get_error_message() ) );
        }

        set_transient( 'wacrm_new_license_' . get_current_user_id(), $result['license_key'], 60 );
        wp_safe_redirect( admin_url( 'admin.php?page=wacrm-central' ) );
        exit;
    }

    public function create_release() {
        if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'wacrm_create_release' ) ) {
            wp_die( 'Not allowed.' );
        }

        $result = $this->service->create_release( array(
            'plugin_slug' => isset( $_POST['plugin_slug'] ) ? wp_unslash( $_POST['plugin_slug'] ) : '',
            'plugin_name' => isset( $_POST['plugin_name'] ) ? wp_unslash( $_POST['plugin_name'] ) : '',
            'version' => isset( $_POST['version'] ) ? wp_unslash( $_POST['version'] ) : '',
            'channel' => isset( $_POST['channel'] ) ? wp_unslash( $_POST['channel'] ) : 'stable',
            'artifact_url' => isset( $_POST['artifact_url'] ) ? wp_unslash( $_POST['artifact_url'] ) : '',
            'requires_wp' => isset( $_POST['requires_wp'] ) ? wp_unslash( $_POST['requires_wp'] ) : '',
            'tested_wp' => isset( $_POST['tested_wp'] ) ? wp_unslash( $_POST['tested_wp'] ) : '',
            'requires_php' => isset( $_POST['requires_php'] ) ? wp_unslash( $_POST['requires_php'] ) : '',
            'checksum_sha256' => isset( $_POST['checksum_sha256'] ) ? wp_unslash( $_POST['checksum_sha256'] ) : '',
            'homepage_url' => isset( $_POST['homepage_url'] ) ? wp_unslash( $_POST['homepage_url'] ) : '',
            'changelog' => isset( $_POST['changelog'] ) ? wp_unslash( $_POST['changelog'] ) : '',
        ) );

        if ( is_wp_error( $result ) ) {
            wp_die( esc_html( $result->get_error_message() ) );
        }

        wp_safe_redirect( add_query_arg( 'wacrm_release_created', 1, admin_url( 'admin.php?page=wacrm-central-releases' ) ) );
        exit;
    }
}
