<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WACRM_Central_License_Service {
    const ENTITLEMENT_TTL = 2592000; // 30 days.
    const REFRESH_AFTER   = 1209600; // 14 days.
    const GRACE_PERIOD    = 1209600; // 14 days.

    public function create_license( array $args = array() ) {
        global $wpdb;
        $defaults = array(
            'order_id'         => null,
            'order_item_id'    => null,
            'user_id'          => null,
            'product_id'       => null,
            'billing_reference'=> null,
            'plan_slug'        => 'free',
            'status'           => 'active',
            'max_activations'  => 1,
            'expires_at'       => null,
            'entitlements'     => array(),
        );
        $args = wp_parse_args( $args, $defaults );

        $key = $this->generate_license_key();
        $now = current_time( 'mysql', true );
        $table = WACRM_Central_DB::licenses_table();

        $inserted = $wpdb->insert(
            $table,
            array(
                'license_key_hash' => $this->hash_license_key( $key ),
                'license_key_cipher' => WACRM_Central_Crypto::encrypt_secret( $key ),
                'license_key_hint' => substr( $key, -9 ),
                'order_id' => $args['order_id'] ? absint( $args['order_id'] ) : null,
                'order_item_id' => $args['order_item_id'] ? absint( $args['order_item_id'] ) : null,
                'user_id' => $args['user_id'] ? absint( $args['user_id'] ) : null,
                'product_id' => $args['product_id'] ? absint( $args['product_id'] ) : null,
                'billing_reference' => $args['billing_reference'] ? sanitize_text_field( $args['billing_reference'] ) : null,
                'plan_slug' => sanitize_key( $args['plan_slug'] ),
                'status' => sanitize_key( $args['status'] ),
                'max_activations' => max( 1, absint( $args['max_activations'] ) ),
                'expires_at' => $args['expires_at'] ? gmdate( 'Y-m-d H:i:s', strtotime( $args['expires_at'] ) ) : null,
                'entitlements' => wp_json_encode( $args['entitlements'] ),
                'created_at' => $now,
                'updated_at' => $now,
            ),
            array( '%s','%s','%s','%d','%d','%d','%d','%s','%s','%s','%d','%s','%s','%s','%s' )
        );

        if ( ! $inserted ) {
            return new WP_Error( 'wacrm_license_create_failed', 'Could not create license.' );
        }

        return array(
            'id'          => (int) $wpdb->insert_id,
            'license_key' => $key,
        );
    }

    public function find_by_key( $license_key ) {
        global $wpdb;
        $table = WACRM_Central_DB::licenses_table();
        $hash = $this->hash_license_key( $license_key );
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE license_key_hash = %s LIMIT 1", $hash ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
    }

    public function reveal_key( $license_id ) {
        global $wpdb;
        $table = WACRM_Central_DB::licenses_table();
        $cipher = $wpdb->get_var( $wpdb->prepare( "SELECT license_key_cipher FROM {$table} WHERE id = %d", absint( $license_id ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return $cipher ? WACRM_Central_Crypto::decrypt_secret( $cipher ) : '';
    }

    public function activate( $license_key, $install_id, $site_url, $plugin_version = '' ) {
        global $wpdb;
        $license = $this->find_by_key( $license_key );
        $valid = $this->validate_license_record( $license );
        if ( is_wp_error( $valid ) ) {
            return $valid;
        }

        $install_id = $this->normalize_install_id( $install_id );
        $site_url = $this->normalize_site_url( $site_url );
        if ( ! $install_id || ! $site_url ) {
            return new WP_Error( 'wacrm_invalid_install', 'install_id and site_url are required.' );
        }

        $activations_table = WACRM_Central_DB::activations_table();
        $existing = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$activations_table} WHERE license_id = %d AND install_id = %s LIMIT 1",
                $license['id'],
                $install_id
            ),
            ARRAY_A
        ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

        $site_hash = hash( 'sha256', $site_url );

        if ( $existing && 'active' === $existing['status'] && ! hash_equals( $existing['site_hash'], $site_hash ) ) {
            return new WP_Error( 'wacrm_site_mismatch', 'This installation ID is already active on another site. Deactivate it before transferring.' );
        }

        if ( ! $existing ) {
            $active_count = (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$activations_table} WHERE license_id = %d AND status = 'active'",
                    $license['id']
                )
            ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

            if ( $active_count >= (int) $license['max_activations'] ) {
                return new WP_Error( 'wacrm_activation_limit', 'Activation limit reached.' );
            }
        }

        $token = WACRM_Central_Crypto::random_token( 32 );
        $token_hash = hash( 'sha256', $token );
        $now = current_time( 'mysql', true );

        if ( $existing ) {
            $wpdb->update(
                $activations_table,
                array(
                    'site_hash' => $site_hash,
                    'site_url' => $site_url,
                    'token_hash' => $token_hash,
                    'status' => 'active',
                    'plugin_version' => sanitize_text_field( $plugin_version ),
                    'last_seen' => $now,
                    'deactivated_at' => null,
                ),
                array( 'id' => $existing['id'] ),
                array( '%s','%s','%s','%s','%s','%s','%s' ),
                array( '%d' )
            );
            $activation_id = (int) $existing['id'];
        } else {
            $wpdb->insert(
                $activations_table,
                array(
                    'license_id' => $license['id'],
                    'install_id' => $install_id,
                    'site_hash' => $site_hash,
                    'site_url' => $site_url,
                    'token_hash' => $token_hash,
                    'status' => 'active',
                    'plugin_version' => sanitize_text_field( $plugin_version ),
                    'first_seen' => $now,
                    'last_seen' => $now,
                ),
                array( '%d','%s','%s','%s','%s','%s','%s','%s','%s' )
            );
            $activation_id = (int) $wpdb->insert_id;
        }

        return $this->activation_response( $license, $activation_id, $install_id, $site_url, $token );
    }

    public function refresh( $install_token, $install_id, $site_url, $plugin_version = '' ) {
        global $wpdb;
        $activations = WACRM_Central_DB::activations_table();
        $licenses = WACRM_Central_DB::licenses_table();
        $token_hash = hash( 'sha256', (string) $install_token );

        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT a.*, l.plan_slug, l.status AS license_status, l.expires_at, l.entitlements, l.max_activations
                 FROM {$activations} a
                 INNER JOIN {$licenses} l ON l.id = a.license_id
                 WHERE a.token_hash = %s AND a.install_id = %s AND a.status = 'active'
                 LIMIT 1",
                $token_hash,
                $this->normalize_install_id( $install_id )
            ),
            ARRAY_A
        ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

        if ( ! $row || ! hash_equals( $row['site_hash'], hash( 'sha256', $this->normalize_site_url( $site_url ) ) ) ) {
            return new WP_Error( 'wacrm_invalid_activation', 'Activation token is invalid.' );
        }

        $license = array(
            'id' => $row['license_id'],
            'plan_slug' => $row['plan_slug'],
            'status' => $row['license_status'],
            'expires_at' => $row['expires_at'],
            'entitlements' => $row['entitlements'],
            'max_activations' => $row['max_activations'],
        );
        $valid = $this->validate_license_record( $license );
        if ( is_wp_error( $valid ) ) {
            return $valid;
        }

        $wpdb->update(
            $activations,
            array(
                'last_seen' => current_time( 'mysql', true ),
                'plugin_version' => sanitize_text_field( $plugin_version ),
            ),
            array( 'id' => $row['id'] ),
            array( '%s','%s' ),
            array( '%d' )
        );

        return $this->activation_response( $license, (int) $row['id'], $row['install_id'], $row['site_url'], (string) $install_token );
    }

    public function deactivate( $install_token ) {
        global $wpdb;
        $table = WACRM_Central_DB::activations_table();
        $updated = $wpdb->update(
            $table,
            array(
                'status' => 'deactivated',
                'deactivated_at' => current_time( 'mysql', true ),
                'last_seen' => current_time( 'mysql', true ),
            ),
            array( 'token_hash' => hash( 'sha256', (string) $install_token ) ),
            array( '%s','%s','%s' ),
            array( '%s' )
        );

        if ( false === $updated || 0 === $updated ) {
            return new WP_Error( 'wacrm_invalid_activation', 'Activation token was not found.' );
        }

        return array( 'deactivated' => true );
    }

    public function latest_release( $slug, $channel = 'stable' ) {
        global $wpdb;
        $slug = sanitize_key( $slug );
        $channel = sanitize_key( $channel );
        $cache_key = 'wacrm_rel_' . md5( $slug . '|' . $channel );
        $cached = get_transient( $cache_key );
        if ( is_array( $cached ) ) {
            return $cached;
        }

        $table = WACRM_Central_DB::releases_table();
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$table} WHERE plugin_slug = %s AND channel = %s AND status = 'published' ORDER BY published_at DESC, id DESC LIMIT 1",
                $slug,
                $channel
            ),
            ARRAY_A
        ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

        if ( $row ) {
            set_transient( $cache_key, $row, 15 * MINUTE_IN_SECONDS );
        }
        return $row;
    }

    public function create_release( array $args ) {
        global $wpdb;
        $table = WACRM_Central_DB::releases_table();
        $now = current_time( 'mysql', true );
        $inserted = $wpdb->insert(
            $table,
            array(
                'plugin_slug' => sanitize_key( $args['plugin_slug'] ),
                'plugin_name' => sanitize_text_field( $args['plugin_name'] ),
                'version' => sanitize_text_field( $args['version'] ),
                'channel' => sanitize_key( isset( $args['channel'] ) ? $args['channel'] : 'stable' ),
                'artifact_url' => esc_url_raw( $args['artifact_url'] ),
                'requires_wp' => sanitize_text_field( isset( $args['requires_wp'] ) ? $args['requires_wp'] : '' ),
                'tested_wp' => sanitize_text_field( isset( $args['tested_wp'] ) ? $args['tested_wp'] : '' ),
                'requires_php' => sanitize_text_field( isset( $args['requires_php'] ) ? $args['requires_php'] : '' ),
                'checksum_sha256' => preg_match( '/^[a-f0-9]{64}$/i', isset( $args['checksum_sha256'] ) ? $args['checksum_sha256'] : '' ) ? strtolower( $args['checksum_sha256'] ) : null,
                'homepage_url' => esc_url_raw( isset( $args['homepage_url'] ) ? $args['homepage_url'] : '' ),
                'changelog' => wp_kses_post( isset( $args['changelog'] ) ? $args['changelog'] : '' ),
                'status' => 'published',
                'published_at' => $now,
                'created_at' => $now,
            ),
            array( '%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s' )
        );

        if ( ! $inserted ) {
            return new WP_Error( 'wacrm_release_create_failed', 'Could not create release. It may already exist.' );
        }

        delete_transient( 'wacrm_rel_' . md5( sanitize_key( $args['plugin_slug'] ) . '|' . sanitize_key( isset( $args['channel'] ) ? $args['channel'] : 'stable' ) ) );
        return (int) $wpdb->insert_id;
    }

    private function activation_response( array $license, $activation_id, $install_id, $site_url, $install_token ) {
        $now = time();
        $token_exp = $now + self::ENTITLEMENT_TTL;
        if ( ! empty( $license['expires_at'] ) ) {
            $license_exp = strtotime( $license['expires_at'] . ' UTC' );
            if ( $license_exp ) {
                $token_exp = min( $token_exp, $license_exp );
            }
        }

        $features = json_decode( isset( $license['entitlements'] ) ? $license['entitlements'] : '{}', true );
        if ( ! is_array( $features ) ) {
            $features = array();
        }

        $payload = array(
            'iss' => home_url( '/' ),
            'aud' => 'wacrm-client',
            'license_id' => (int) $license['id'],
            'activation_id' => (int) $activation_id,
            'install_id' => (string) $install_id,
            'site_hash' => hash( 'sha256', $site_url ),
            'plan' => sanitize_key( $license['plan_slug'] ),
            'features' => $features,
            'iat' => $now,
            'refresh_after' => min( $token_exp, $now + self::REFRESH_AFTER ),
            'exp' => $token_exp,
            'grace_until' => $token_exp + self::GRACE_PERIOD,
        );

        $signed = WACRM_Central_Crypto::sign_payload( $payload );
        if ( is_wp_error( $signed ) ) {
            return $signed;
        }

        return array(
            'install_token' => $install_token,
            'entitlement' => $signed,
            'plan' => $payload['plan'],
            'features' => $features,
            'refresh_after' => $payload['refresh_after'],
            'expires_at' => $payload['exp'],
            'grace_until' => $payload['grace_until'],
        );
    }

    private function validate_license_record( $license ) {
        if ( ! $license ) {
            return new WP_Error( 'wacrm_license_not_found', 'License key was not found.' );
        }
        if ( 'active' !== $license['status'] ) {
            return new WP_Error( 'wacrm_license_inactive', 'License is not active.' );
        }
        if ( ! empty( $license['expires_at'] ) && strtotime( $license['expires_at'] . ' UTC' ) < time() ) {
            return new WP_Error( 'wacrm_license_expired', 'License has expired.' );
        }
        return true;
    }

    private function hash_license_key( $key ) {
        return hash( 'sha256', strtoupper( trim( (string) $key ) ) );
    }

    private function generate_license_key() {
        $raw = strtoupper( bin2hex( random_bytes( 12 ) ) );
        return 'WACRM-' . implode( '-', str_split( $raw, 6 ) );
    }

    private function normalize_install_id( $install_id ) {
        return preg_replace( '/[^a-zA-Z0-9._:-]/', '', substr( (string) $install_id, 0, 80 ) );
    }

    private function normalize_site_url( $site_url ) {
        $site_url = esc_url_raw( trim( (string) $site_url ) );
        if ( ! $site_url ) {
            return '';
        }
        $parts = wp_parse_url( $site_url );
        if ( empty( $parts['host'] ) ) {
            return '';
        }
        $scheme = ! empty( $parts['scheme'] ) ? strtolower( $parts['scheme'] ) : 'https';
        $host = strtolower( $parts['host'] );
        $port = ! empty( $parts['port'] ) ? ':' . absint( $parts['port'] ) : '';
        return $scheme . '://' . $host . $port;
    }
}
