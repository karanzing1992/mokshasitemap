<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WACRM_Central_WooCommerce {
    private $service;

    public function __construct( WACRM_Central_License_Service $service ) {
        $this->service = $service;
    }

    public function register() {
        if ( ! class_exists( 'WooCommerce' ) ) {
            return;
        }

        add_action( 'woocommerce_product_options_general_product_data', array( $this, 'product_fields' ) );
        add_action( 'woocommerce_process_product_meta', array( $this, 'save_product_fields' ) );
        add_action( 'woocommerce_order_status_processing', array( $this, 'issue_order_licenses' ) );
        add_action( 'woocommerce_order_status_completed', array( $this, 'issue_order_licenses' ) );
        add_action( 'woocommerce_email_after_order_table', array( $this, 'email_licenses' ), 20, 4 );
    }

    public function product_fields() {
        echo '<div class="options_group">';
        woocommerce_wp_checkbox( array(
            'id' => '_wacrm_license_enabled',
            'label' => __( 'WACRM license product', 'wacrm-central' ),
            'description' => __( 'Issue a WACRM license when this product is paid.', 'wacrm-central' ),
        ) );
        woocommerce_wp_text_input( array(
            'id' => '_wacrm_plan_slug',
            'label' => __( 'Plan slug', 'wacrm-central' ),
            'placeholder' => 'pro',
        ) );
        woocommerce_wp_text_input( array(
            'id' => '_wacrm_max_activations',
            'label' => __( 'Site activations', 'wacrm-central' ),
            'type' => 'number',
            'custom_attributes' => array( 'min' => 1, 'step' => 1 ),
            'value' => get_post_meta( get_the_ID(), '_wacrm_max_activations', true ) ?: 1,
        ) );
        woocommerce_wp_text_input( array(
            'id' => '_wacrm_license_days',
            'label' => __( 'License days', 'wacrm-central' ),
            'description' => __( '0 means no expiry.', 'wacrm-central' ),
            'type' => 'number',
            'custom_attributes' => array( 'min' => 0, 'step' => 1 ),
            'value' => get_post_meta( get_the_ID(), '_wacrm_license_days', true ) ?: 0,
        ) );
        woocommerce_wp_textarea_input( array(
            'id' => '_wacrm_entitlements_json',
            'label' => __( 'Entitlements JSON', 'wacrm-central' ),
            'description' => __( 'Example: {"automations":true,"agents":5}', 'wacrm-central' ),
        ) );
        echo '</div>';
    }

    public function save_product_fields( $product_id ) {
        update_post_meta( $product_id, '_wacrm_license_enabled', isset( $_POST['_wacrm_license_enabled'] ) ? 'yes' : 'no' ); // phpcs:ignore WordPress.Security.NonceVerification.Missing

        $fields = array( '_wacrm_plan_slug', '_wacrm_max_activations', '_wacrm_license_days', '_wacrm_entitlements_json' );
        foreach ( $fields as $field ) {
            if ( isset( $_POST[ $field ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
                update_post_meta( $product_id, $field, sanitize_textarea_field( wp_unslash( $_POST[ $field ] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
            }
        }
    }

    public function issue_order_licenses( $order_id ) {
        $order = wc_get_order( $order_id );
        if ( ! $order ) {
            return;
        }

        foreach ( $order->get_items() as $item_id => $item ) {
            if ( $item->get_meta( '_wacrm_license_id', true ) ) {
                continue;
            }

            $product_id = $item->get_product_id();
            if ( 'yes' !== get_post_meta( $product_id, '_wacrm_license_enabled', true ) ) {
                continue;
            }

            $plan = sanitize_key( get_post_meta( $product_id, '_wacrm_plan_slug', true ) ?: 'pro' );
            $max = max( 1, absint( get_post_meta( $product_id, '_wacrm_max_activations', true ) ?: 1 ) );
            $days = absint( get_post_meta( $product_id, '_wacrm_license_days', true ) );
            $raw_entitlements = get_post_meta( $product_id, '_wacrm_entitlements_json', true );
            $entitlements = json_decode( $raw_entitlements ?: '{}', true );
            if ( ! is_array( $entitlements ) ) {
                $entitlements = array();
            }

            $expires = $days ? gmdate( 'Y-m-d H:i:s', time() + DAY_IN_SECONDS * $days ) : null;
            $created = $this->service->create_license( array(
                'order_id' => $order_id,
                'order_item_id' => $item_id,
                'user_id' => $order->get_user_id(),
                'product_id' => $product_id,
                'billing_reference' => $order->get_order_key(),
                'plan_slug' => $plan,
                'max_activations' => $max,
                'expires_at' => $expires,
                'entitlements' => $entitlements,
            ) );

            if ( is_wp_error( $created ) ) {
                $order->add_order_note( 'WACRM license issuance failed for item #' . $item_id . ': ' . $created->get_error_message() );
                continue;
            }

            $item->update_meta_data( '_wacrm_license_id', $created['id'] );
            $item->save();
            $order->add_order_note( 'WACRM license issued: ' . $created['license_key'] );
        }
    }

    public function email_licenses( $order, $sent_to_admin, $plain_text, $email ) {
        if ( $sent_to_admin || ! $order instanceof WC_Order ) {
            return;
        }

        $keys = array();
        foreach ( $order->get_items() as $item ) {
            $license_id = absint( $item->get_meta( '_wacrm_license_id', true ) );
            if ( $license_id ) {
                $key = $this->service->reveal_key( $license_id );
                if ( $key ) {
                    $keys[] = array( 'name' => $item->get_name(), 'key' => $key );
                }
            }
        }

        if ( ! $keys ) {
            return;
        }

        if ( $plain_text ) {
            echo "\nWACRM LICENSES\n";
            foreach ( $keys as $entry ) {
                echo esc_html( $entry['name'] . ': ' . $entry['key'] ) . "\n";
            }
            return;
        }

        echo '<h2>' . esc_html__( 'Your WACRM license', 'wacrm-central' ) . '</h2><ul>';
        foreach ( $keys as $entry ) {
            echo '<li><strong>' . esc_html( $entry['name'] ) . '</strong>: <code>' . esc_html( $entry['key'] ) . '</code></li>';
        }
        echo '</ul>';
    }
}
