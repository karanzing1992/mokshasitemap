<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WACRM_Central_DB {
    const DB_VERSION = '0.1.0';

    public static function licenses_table() {
        global $wpdb;
        return $wpdb->prefix . 'wacrm_licenses';
    }

    public static function activations_table() {
        global $wpdb;
        return $wpdb->prefix . 'wacrm_activations';
    }

    public static function releases_table() {
        global $wpdb;
        return $wpdb->prefix . 'wacrm_releases';
    }

    public static function activate() {
        self::install_schema();
        update_option( 'wacrm_central_db_version', self::DB_VERSION, false );
        WACRM_Central_Crypto::ensure_keypair();
    }

    public static function maybe_upgrade() {
        $installed = get_option( 'wacrm_central_db_version' );
        if ( self::DB_VERSION !== $installed ) {
            self::install_schema();
            update_option( 'wacrm_central_db_version', self::DB_VERSION, false );
        }
    }

    private static function install_schema() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset = $wpdb->get_charset_collate();
        $licenses = self::licenses_table();
        $activations = self::activations_table();
        $releases = self::releases_table();

        $sql_licenses = "CREATE TABLE {$licenses} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            license_key_hash CHAR(64) NOT NULL,
            license_key_cipher LONGTEXT NOT NULL,
            license_key_hint VARCHAR(32) NOT NULL,
            order_id BIGINT UNSIGNED NULL,
            order_item_id BIGINT UNSIGNED NULL,
            user_id BIGINT UNSIGNED NULL,
            product_id BIGINT UNSIGNED NULL,
            billing_reference VARCHAR(120) NULL,
            plan_slug VARCHAR(100) NOT NULL DEFAULT 'free',
            status VARCHAR(24) NOT NULL DEFAULT 'active',
            max_activations INT UNSIGNED NOT NULL DEFAULT 1,
            expires_at DATETIME NULL,
            entitlements LONGTEXT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY license_key_hash (license_key_hash),
            KEY order_id (order_id),
            KEY user_id (user_id),
            KEY status_expires (status, expires_at),
            KEY plan_slug (plan_slug)
        ) {$charset};";

        $sql_activations = "CREATE TABLE {$activations} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            license_id BIGINT UNSIGNED NOT NULL,
            install_id VARCHAR(80) NOT NULL,
            site_hash CHAR(64) NOT NULL,
            site_url VARCHAR(255) NOT NULL,
            token_hash CHAR(64) NOT NULL,
            status VARCHAR(24) NOT NULL DEFAULT 'active',
            plugin_version VARCHAR(40) NULL,
            first_seen DATETIME NOT NULL,
            last_seen DATETIME NOT NULL,
            deactivated_at DATETIME NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY license_install (license_id, install_id),
            KEY token_hash (token_hash),
            KEY license_status (license_id, status),
            KEY site_hash (site_hash)
        ) {$charset};";

        $sql_releases = "CREATE TABLE {$releases} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            plugin_slug VARCHAR(160) NOT NULL,
            plugin_name VARCHAR(200) NOT NULL,
            version VARCHAR(40) NOT NULL,
            channel VARCHAR(32) NOT NULL DEFAULT 'stable',
            artifact_url TEXT NOT NULL,
            requires_wp VARCHAR(20) NULL,
            tested_wp VARCHAR(20) NULL,
            requires_php VARCHAR(20) NULL,
            checksum_sha256 CHAR(64) NULL,
            homepage_url TEXT NULL,
            changelog LONGTEXT NULL,
            status VARCHAR(24) NOT NULL DEFAULT 'published',
            published_at DATETIME NOT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY slug_version_channel (plugin_slug, version, channel),
            KEY lookup_release (plugin_slug, channel, status, published_at)
        ) {$charset};";

        dbDelta( $sql_licenses );
        dbDelta( $sql_activations );
        dbDelta( $sql_releases );
    }
}
