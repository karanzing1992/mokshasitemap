<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WACRM_Central_REST {
    private $service;
    private $namespace = 'wacrm-central/v1';

    public function __construct( WACRM_Central_License_Service $service ) {
        $this->service = $service;
    }

    public function register() {
        add_action( 'rest_api_init', array( $this, 'routes' ) );
    }

    public function routes() {
        register_rest_route( $this->namespace, '/health', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array( $this, 'health' ),
            'permission_callback' => '__return_true',
        ) );

        register_rest_route( $this->namespace, '/public-key', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array( $this, 'public_key' ),
            'permission_callback' => '__return_true',
        ) );

        register_rest_route( $this->namespace, '/licenses/activate', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array( $this, 'activate' ),
            'permission_callback' => '__return_true',
        ) );

        register_rest_route( $this->namespace, '/licenses/refresh', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array( $this, 'refresh' ),
            'permission_callback' => '__return_true',
        ) );

        register_rest_route( $this->namespace, '/licenses/deactivate', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array( $this, 'deactivate' ),
            'permission_callback' => '__return_true',
        ) );

        register_rest_route( $this->namespace, '/updates/(?P<slug>[a-z0-9-]+)', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array( $this, 'update_metadata' ),
            'permission_callback' => '__return_true',
            'args' => array(
                'slug' => array( 'sanitize_callback' => 'sanitize_key' ),
                'channel' => array( 'sanitize_callback' => 'sanitize_key', 'default' => 'stable' ),
            ),
        ) );
    }

    public function health() {
        return rest_ensure_response( array(
            'ok' => true,
            'version' => WACRM_CENTRAL_VERSION,
            'signing_ready' => (bool) WACRM_Central_Crypto::get_public_key(),
            'time' => time(),
        ) );
    }

    public function public_key() {
        return rest_ensure_response( array(
            'algorithm' => 'RS256',
            'public_key' => WACRM_Central_Crypto::get_public_key(),
        ) );
    }

    public function activate( WP_REST_Request $request ) {
        if ( ! $this->allow_request( 'activate' ) ) {
            return new WP_Error( 'wacrm_rate_limited', 'Too many requests.', array( 'status' => 429 ) );
        }

        $result = $this->service->activate(
            (string) $request->get_param( 'license_key' ),
            (string) $request->get_param( 'install_id' ),
            (string) $request->get_param( 'site_url' ),
            (string) $request->get_param( 'plugin_version' )
        );
        return $this->result( $result );
    }

    public function refresh( WP_REST_Request $request ) {
        if ( ! $this->allow_request( 'refresh' ) ) {
            return new WP_Error( 'wacrm_rate_limited', 'Too many requests.', array( 'status' => 429 ) );
        }

        $result = $this->service->refresh(
            (string) $request->get_param( 'install_token' ),
            (string) $request->get_param( 'install_id' ),
            (string) $request->get_param( 'site_url' ),
            (string) $request->get_param( 'plugin_version' )
        );
        return $this->result( $result );
    }

    public function deactivate( WP_REST_Request $request ) {
        if ( ! $this->allow_request( 'deactivate' ) ) {
            return new WP_Error( 'wacrm_rate_limited', 'Too many requests.', array( 'status' => 429 ) );
        }
        return $this->result( $this->service->deactivate( (string) $request->get_param( 'install_token' ) ) );
    }

    public function update_metadata( WP_REST_Request $request ) {
        $release = $this->service->latest_release( $request['slug'], $request->get_param( 'channel' ) ?: 'stable' );
        if ( ! $release ) {
            return new WP_Error( 'wacrm_release_not_found', 'No release found.', array( 'status' => 404 ) );
        }

        return rest_ensure_response( array(
            'name' => $release['plugin_name'],
            'slug' => $release['plugin_slug'],
            'version' => $release['version'],
            'download_url' => $release['artifact_url'],
            'requires' => $release['requires_wp'],
            'tested' => $release['tested_wp'],
            'requires_php' => $release['requires_php'],
            'last_updated' => mysql2date( 'c', $release['published_at'], false ),
            'homepage' => $release['homepage_url'],
            'sections' => array(
                'description' => 'WACRM WordPress plugin.',
                'changelog' => $release['changelog'],
            ),
            'checksum_sha256' => $release['checksum_sha256'],
        ) );
    }

    private function result( $result ) {
        if ( is_wp_error( $result ) ) {
            $code = $result->get_error_code();
            $status = in_array( $code, array( 'wacrm_license_not_found', 'wacrm_invalid_activation' ), true ) ? 401 : 400;
            $result->add_data( array( 'status' => $status ) );
            return $result;
        }
        return rest_ensure_response( $result );
    }

    private function allow_request( $bucket ) {
        $ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'unknown';
        $key = 'wacrm_rl_' . md5( $bucket . '|' . $ip );
        $count = (int) get_transient( $key );
        if ( $count >= 60 ) {
            return false;
        }
        set_transient( $key, $count + 1, 5 * MINUTE_IN_SECONDS );
        return true;
    }
}
