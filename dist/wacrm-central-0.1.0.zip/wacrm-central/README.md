# WACRM Central

A lightweight WordPress authority for WACRM licensing and update metadata.

## Design goal

The customer's WordPress site does the work. WACRM Central never proxies WhatsApp messages, CRM data, media, automations, or background jobs.

Central responsibilities are intentionally limited to:

- WooCommerce-backed license issuance
- site activation/deactivation
- signed, locally verifiable feature entitlements
- occasional entitlement refresh
- public/core plugin update metadata
- release metadata pointing to static/CDN artifact URLs

## Install

1. Upload `wacrm-central.zip` in **Plugins → Add Plugin → Upload Plugin**.
2. Activate it.
3. Open **WACRM Central** in WP Admin.
4. The plugin generates an RSA signing keypair. The private key is encrypted at rest using keys derived from WordPress auth salts. The public key is shown in the dashboard and exposed at the public-key REST endpoint.
5. If WooCommerce is installed, mark products as **WACRM license product** and configure plan, site count, expiry and entitlements JSON.

## REST API

Base:

`/wp-json/wacrm-central/v1/`

Endpoints:

- `GET health`
- `GET public-key`
- `POST licenses/activate`
- `POST licenses/refresh`
- `POST licenses/deactivate`
- `GET updates/{plugin-slug}?channel=stable`

### Activate

```json
{
  "license_key": "WACRM-...",
  "install_id": "uuid-generated-by-client",
  "site_url": "https://customer.example",
  "plugin_version": "0.1.0"
}
```

The response contains an opaque `install_token` and an RS256-signed entitlement. The customer plugin stores both locally and verifies the entitlement using the embedded public key. Normal WhatsApp/CRM activity requires no call to Central.

### Refresh cadence

Current entitlement defaults:

- signed token TTL: 30 days
- suggested refresh: 14 days
- offline grace after token expiry: 14 days

These values intentionally keep central traffic tiny.

## Releases

The Releases screen stores update metadata and a direct artifact URL. Put release ZIPs on static/object storage or a CDN. Central only returns JSON; it does not need to serve the ZIP bytes.

The metadata shape is compatible with the common Plugin Update Checker pattern.

## Database

The plugin creates only three small tables:

- `{prefix}wacrm_licenses`
- `{prefix}wacrm_activations`
- `{prefix}wacrm_releases`

No customer WhatsApp messages, contacts, media, CRM activity, or automation data are stored centrally.

## v0.1 scope

Included:

- license generation
- WooCommerce product → license configuration
- idempotent issuance on paid order states
- order/email license delivery
- activation limits
- license expiry
- encrypted license key storage
- opaque installation tokens
- signed entitlements
- local-verification public key
- update metadata with 15-minute caching
- basic IP rate limiting for activation endpoints
- admin dashboards for licenses/releases

Deferred intentionally:

- WooCommerce Subscriptions renewal hooks
- refunds automatically suspending licenses
- multi-product add-on entitlements
- private premium artifact authorization
- customer self-service activation management
- license transfer cooldowns
- webhook callbacks from payment providers
- telemetry beyond activation/version heartbeat
